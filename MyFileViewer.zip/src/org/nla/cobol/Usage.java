package org.nla.cobol;


public enum Usage {
	comp1,
	comp2,
	comp3,
	comp4,
	comp5,
	display,
	display1,
	index,
	binary,
	packed,
	pointer,
}
